<?php
header('Refresh: 0; URL=./php/index.php');
?>