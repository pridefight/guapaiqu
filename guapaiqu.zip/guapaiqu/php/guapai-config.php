<?php
define('DB_NAME', 'guapaiqu');

/** MySQL database username */
define('DB_USER', 'guapaiadmin');

/** MySQL database password */
define('DB_PASSWORD', 'guapaiqulepass');

/** MySQL hostname */
define('DB_HOST', '127.0.0.1');
?>